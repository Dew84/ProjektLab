namespace TradeByte.Dtos.Conversation
{
    public class ConversationDto
    {
        public int Id { get; set; }
        public int User1Id { get; set; }
        public int User2Id { get; set; }
    }
}