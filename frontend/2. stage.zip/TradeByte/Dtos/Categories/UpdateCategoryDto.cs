﻿namespace TradeByte.Dtos.Categories
{
    /// <summary>Kategória frissítésének bemenete.</summary>
    public class UpdateCategoryDto
    {
        public string Name { get; set; } = "";
    }
}
