﻿namespace TradeByte.Dtos.Categories
{
    /// <summary>Új kategória létrehozásának bemenete.</summary>
    public class CreateCategoryDto
    {
        public string Name { get; set; } = "";
    }
}
