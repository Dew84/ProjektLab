﻿/*namespace TradeByte.Enums
{
    public enum ConditionType
    {
        New = 0,
        LikeNew = 1,
        Used = 2,
        
    }
}
*/