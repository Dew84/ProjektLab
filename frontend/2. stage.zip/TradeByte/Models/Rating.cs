using TradeByte.Models;

public class Rating
{
    public int Id { get; set; }

    public int RatedUserId { get; set; }      // Az a felhaszn�l�, akit �rt�kelnek
    public int RaterUserId { get; set; }      // Az a felhaszn�l�, aki �rt�kel

    public int Value { get; set; }            // 1�5 csillag

    // Opcion�lis: sz�veges �rt�kel�s (k�s�bb fejleszthet�)
    // public string? Comment { get; set; }

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow; //h�tha kell
    // Navig�ci�s property-k:
    public User RatedUser { get; set; } = null!;
    public User RaterUser { get; set; } = null!;
}
