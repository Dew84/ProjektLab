package com.example.workoutapp.UI;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutapp.R;
import com.example.workoutapp.data.WorkoutDatabase;
import com.example.workoutapp.data.Workout;
import com.example.workoutapp.data.WorkoutAdapter;

import java.util.List;
import java.util.concurrent.Executors;

public class WorkoutListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WorkoutAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_list);

        recyclerView = findViewById(R.id.recyclerViewWorkouts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setHasFixedSize(true);




        List<Workout> workoutList = WorkoutDatabase.getInstance(this).workoutDao().getAll();
        adapter = new WorkoutAdapter(workoutList, workout -> {
            // Törlés logika
            Executors.newSingleThreadExecutor().execute(() -> {
                WorkoutDatabase.getInstance(this).workoutDao().delete(workout);
                runOnUiThread(this::refreshWorkouts);
            });
        });

        recyclerView.setAdapter(adapter);


    }

    // Betöltés és frissítés logika
    private void refreshWorkouts() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Workout> updatedWorkouts = WorkoutDatabase.getInstance(this).workoutDao().getAll();
            runOnUiThread(() -> adapter.updateList(updatedWorkouts));
        });
    }
}
