package com.example.workoutapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.concurrent.Executors;
import com.example.workoutapp.UI.AddWorkoutActivity;
import com.example.workoutapp.data.Workout;
import com.example.workoutapp.data.WorkoutAdapter;
import com.example.workoutapp.data.WorkoutDatabase;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText etName, etGoal, etWeight;
    Button btnSave, btnAddWorkout;
    RecyclerView recyclerView;
    WorkoutAdapter adapter;
    WorkoutDatabase db;
    TextView tvGoalStats;
    Spinner spGoal;
    String[] goals = {"Fogyás", "Izomnövelés", "Általános fittség", "Állóképesség", "Egészségmegőrzés"};



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etGoal = findViewById(R.id.etGoal);
        etWeight = findViewById(R.id.etWeight);
        btnSave = findViewById(R.id.btnSave);
        btnAddWorkout = findViewById(R.id.btnAddWorkout);
        recyclerView = findViewById(R.id.recyclerView);
        tvGoalStats = findViewById(R.id.tvGoalStats);
        spGoal = findViewById(R.id.spGoal);

        ArrayAdapter<String> adapterGoal = new ArrayAdapter<>(
                this,
                android.R.layout.simple_spinner_item,
                goals
        );
        adapterGoal.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spGoal.setAdapter(adapterGoal);


        db = WorkoutDatabase.getInstance(this);

        // Load saved profile data
        SharedPreferences prefs = getSharedPreferences("ProfilePrefs", MODE_PRIVATE);
        etName.setText(prefs.getString("name", ""));
        etGoal.setText(prefs.getString("goal", ""));
        etWeight.setText(prefs.getString("weight", ""));

        // Save profile data
        btnSave.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("name", etName.getText().toString());
            editor.putString("weight", etWeight.getText().toString());
            editor.putString("goal", spGoal.getSelectedItem().toString());
            editor.apply();
            Toast.makeText(this, "Profil elmentve!", Toast.LENGTH_SHORT).show();
        });


        btnAddWorkout.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddWorkoutActivity.class);
            startActivity(intent);
        });

        adapter = new WorkoutAdapter(new java.util.ArrayList<>(), workout -> {
            Executors.newSingleThreadExecutor().execute(() -> {
                db.workoutDao().delete(workout);
                runOnUiThread(this::refreshWorkouts);
            });
        });
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);
    }




    @Override
    protected void onResume() {
        super.onResume();
        refreshWorkouts();
        updateStatistics();
    }

    private void refreshWorkouts() {
        Executors.newSingleThreadExecutor().execute(() -> {
            List<Workout> updatedWorkouts = db.workoutDao().getAll();
            runOnUiThread(() -> {
                adapter.updateList(updatedWorkouts);
                if (updatedWorkouts.isEmpty()) {
                    Toast.makeText(this, "Még nincs felvitt edzés!", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private void updateStatistics() {
        Executors.newSingleThreadExecutor().execute(() -> {
            int totalCalories = db.workoutDao().getTotalCalories();
            int workoutCount = db.workoutDao().getWorkoutCount();
            runOnUiThread(() -> {
                TextView tvStats = findViewById(R.id.tvStats);
                tvStats.setText("Összes edzés: " + workoutCount + " | Összes kalória: " + totalCalories + " kcal");
                SharedPreferences prefs = getSharedPreferences("ProfilePrefs", MODE_PRIVATE);
                String goal = prefs.getString("goal", "").toLowerCase();
                String savedGoal = prefs.getString("goal", "");
                if (!savedGoal.isEmpty()) {
                    int index = java.util.Arrays.asList(goals).indexOf(savedGoal);
                    if (index >= 0) spGoal.setSelection(index);
                }

                int targetCalories = 0;

                if (goal.contains("fogyás")) {
                    targetCalories = 600;
                } else if (goal.contains("izomnövelés")) {
                    targetCalories = 400;
                } else {
                    targetCalories = 500; // általános cél
                }

                tvGoalStats.setText("Cél: napi " + targetCalories + " kcal | Elért: " + totalCalories + " kcal");

            });
        });
    }
}