package com.example.workoutapp.data;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutapp.R;
import java.util.List;

public class WorkoutAdapter extends RecyclerView.Adapter<WorkoutAdapter.WorkoutViewHolder> {

    private List<Workout> workoutList;
    private final OnDeleteClickListener deleteClickListener;

    public WorkoutAdapter(List<Workout> workoutList, OnDeleteClickListener listener) {
        this.workoutList = workoutList;
        this.deleteClickListener = listener;
    }

    @NonNull
    @Override
    public WorkoutViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_workout, parent, false);
        return new WorkoutViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull WorkoutViewHolder holder, int position) {
        Workout workout = workoutList.get(position);
        holder.tvType.setText("Típus: " + workout.type);
        holder.tvDuration.setText("Időtartam: " + workout.durationMinutes + " perc");
        holder.tvCalories.setText("Kalória: " + workout.calories + " kcal");

        holder.btnDelete.setOnClickListener(v -> {
            if (deleteClickListener != null) {
                deleteClickListener.onDeleteClick(workout);
            }
        });
    }

    @Override
    public int getItemCount() {
        return workoutList.size();
    }

    public void updateList(List<Workout> newWorkouts) {
        this.workoutList = newWorkouts;
        notifyDataSetChanged();
    }

    public static class WorkoutViewHolder extends RecyclerView.ViewHolder {
        TextView tvType, tvDuration, tvCalories;
        Button btnDelete;

        public WorkoutViewHolder(View itemView) {
            super(itemView);
            tvType = itemView.findViewById(R.id.tvType);
            tvDuration = itemView.findViewById(R.id.tvDuration);
            tvCalories = itemView.findViewById(R.id.tvCalories);
            btnDelete = itemView.findViewById(R.id.btnDelete);
        }
    }

    public interface OnDeleteClickListener {
        void onDeleteClick(Workout workout);
    }


}
