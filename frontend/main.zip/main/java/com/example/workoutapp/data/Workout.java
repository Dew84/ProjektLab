package com.example.workoutapp.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity
public class Workout {

    @PrimaryKey(autoGenerate = true)
    public int id;

    public String type;           // Edzéstípus (pl. MMA, GYM)
    public int durationMinutes;   // Időtartam percben
    public long timestamp;        // Unix timestamp (System.currentTimeMillis())
    public int calories;          // Kiszámított kalória
    public String notes;          // Megjegyzés


}
