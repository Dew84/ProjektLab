package com.example.workoutapp.data;

public enum WorkoutType {
    GYM(6),
    MMA(10),
    BOX(9),
    RUNNING(11),
    YOGA(4),
    CROSSFIT(7);


    public final int kcalPerMinute;

    WorkoutType(int kcalPerMinute) {
        this.kcalPerMinute = kcalPerMinute;
    }

    public int calculateCalories(int durationMinutes) {
        return kcalPerMinute * durationMinutes;
    }
}
