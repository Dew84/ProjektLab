package com.example.workoutapp.data;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface WorkoutDao {

    @Insert
    void insert(Workout workout);

    @Query("SELECT * FROM Workout ORDER BY timestamp DESC")
    List<Workout> getAll();

    @Query("SELECT SUM(calories) FROM Workout")
    int getTotalCalories();

    @Query("SELECT COUNT(*) FROM Workout")
    int getWorkoutCount();

    @Delete
    void delete(Workout workout);

}
