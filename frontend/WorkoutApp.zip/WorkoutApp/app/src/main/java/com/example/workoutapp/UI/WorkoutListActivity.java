package com.example.workoutapp.UI;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.workoutapp.R;
import com.example.workoutapp.data.WorkoutDatabase;
import com.example.workoutapp.data.Workout;
import com.example.workoutapp.data.WorkoutAdapter;

import java.util.List;

public class WorkoutListActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private WorkoutAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_workout_list);

        recyclerView = findViewById(R.id.recyclerViewWorkouts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        List<Workout> workoutList = WorkoutDatabase.getInstance(this).workoutDao().getAll();
        adapter = new WorkoutAdapter(workoutList);
        recyclerView.setAdapter(adapter);
    }
}
