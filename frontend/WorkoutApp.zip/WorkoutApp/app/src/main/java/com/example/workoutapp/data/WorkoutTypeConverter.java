package com.example.workoutapp.data;

import androidx.room.TypeConverter;

public class WorkoutTypeConverter {

    @TypeConverter
    public static String fromWorkoutType(WorkoutType type) {
        return type.name();
    }

    @TypeConverter
    public static WorkoutType toWorkoutType(String type) {
        return WorkoutType.valueOf(type);
    }
}
