/*package com.example.workoutapp.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import androidx.room.TypeConverters;

public class Appdatabase {
    @Database(entities = {Workout.class}, version = 1)
    @TypeConverters({WorkoutTypeConverter.class})
    public abstract class AppDatabase extends RoomDatabase {
        public abstract WorkoutDao workoutDao();
    }

}
*/