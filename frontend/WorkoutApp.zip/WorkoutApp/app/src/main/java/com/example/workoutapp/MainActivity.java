package com.example.workoutapp;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.room.Room;

import com.example.workoutapp.data.Workout;
import com.example.workoutapp.data.WorkoutAdapter;
import com.example.workoutapp.data.WorkoutDatabase;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    EditText etName, etGoal, etWeight;
    Button btnSave;
    RecyclerView recyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etGoal = findViewById(R.id.etGoal);
        etWeight = findViewById(R.id.etWeight);
        btnSave = findViewById(R.id.btnSave);


        // betöltés
        SharedPreferences prefs = getSharedPreferences("ProfilePrefs", MODE_PRIVATE);
        etName.setText(prefs.getString("name", ""));
        etGoal.setText(prefs.getString("goal", ""));
        etWeight.setText(prefs.getString("weight", ""));
        // mentés
        btnSave.setOnClickListener(v -> {
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString("name", etName.getText().toString());
            editor.putString("goal", etGoal.getText().toString());
            editor.putString("weight", etWeight.getText().toString());
            editor.apply();
            Toast.makeText(this, "Profil elmentve!", Toast.LENGTH_SHORT).show();
        });
        // RecyclerView betöltése
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        WorkoutDatabase db = Room.databaseBuilder(getApplicationContext(), WorkoutDatabase.class, "workout-db").allowMainThreadQueries().build();
        List<Workout> workouts = db.workoutDao().getAll();

        WorkoutAdapter adapter = new WorkoutAdapter(workouts);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

    }
}
