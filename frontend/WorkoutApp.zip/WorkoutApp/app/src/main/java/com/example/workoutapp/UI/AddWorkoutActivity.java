package com.example.workoutapp.UI;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import com.example.workoutapp.R;
import com.example.workoutapp.data.Workout;
import com.example.workoutapp.data.WorkoutDatabase;
import com.example.workoutapp.data.WorkoutType;

public class AddWorkoutActivity extends AppCompatActivity {

    private Spinner spinnerType;
    private EditText etDuration, etNotes;
    private TextView tvCalories;
    private Button btnSave;

    private WorkoutType selectedType;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_workout);

        // 1. Layout elemek összekötése
        spinnerType = findViewById(R.id.spinnerType);
        etDuration = findViewById(R.id.etDuration);
        etNotes = findViewById(R.id.etNotes);
        tvCalories = findViewById(R.id.tvCalories);
        btnSave = findViewById(R.id.btnSaveWorkout);

        // 2. Spinner feltöltése enum alapján
        ArrayAdapter<WorkoutType> adapter = new ArrayAdapter<>(
                this, android.R.layout.simple_spinner_item, WorkoutType.values()
        );
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerType.setAdapter(adapter);

        // 3. Spinner kiválasztás kezelése
        spinnerType.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedType = (WorkoutType) parent.getItemAtPosition(position);
                updateCalories();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                selectedType = null;
            }
        });

        // 4. Mentés gomb logikája
        btnSave.setOnClickListener(v -> {
            String durationStr = etDuration.getText().toString();
            String notes = etNotes.getText().toString();

            if (durationStr.isEmpty() || selectedType == null) {
                Toast.makeText(this, "Tölts ki minden mezőt!", Toast.LENGTH_SHORT).show();
                return;
            }

            int duration = Integer.parseInt(durationStr);
            int calories = selectedType.calculateCalories(duration);

            Workout workout = new Workout();
            workout.type = selectedType.name();

            workout.durationMinutes = duration;
            workout.calories = calories;
            workout.notes = notes;
            workout.timestamp = System.currentTimeMillis();

            new Thread(() -> {
                WorkoutDatabase.getInstance(this).workoutDao().insert(workout);
                runOnUiThread(() -> {
                    Toast.makeText(this, "Edzés elmentve!", Toast.LENGTH_SHORT).show();
                    finish(); // visszalépés a főképernyőre
                });
            }).start();
        });
    }

    // Kiszámolt kalória frissítése valós időben
    private void updateCalories() {
        String durationStr = etDuration.getText().toString();
        if (!durationStr.isEmpty() && selectedType != null) {
            int duration = Integer.parseInt(durationStr);
            int calories = selectedType.calculateCalories(duration);
            tvCalories.setText("Kiszámolt kalória: " + calories + " kcal");
        } else {
            tvCalories.setText("Kiszámolt kalória: 0 kcal");
        }
    }
}
